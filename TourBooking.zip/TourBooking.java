import java.util.Scanner;

public class TourBooking {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int age = 0;
        int fanCount = 0;
        int city = 0;
        String more = "";
        String artistName = "Taylor Swift";

        System.out.println("Welcome to the " + artistName + " Tour Booking System!");

        System.out.println("Options: 1. Manila, 2. Makati, 3. Pasay");
        System.out.print("Please select a city for the tour (1-3): ");

        
        city = input.nextInt();

        String cityName = "";
        switch (city) {
            case 1:
                cityName = "Manila";
                System.out.println("You selected Manila");
                break;
            case 2:
                cityName = "Makati";
                System.out.println("You selected Makati");
                break;
            case 3:
                cityName = "Pasay";
                System.out.println("You selected Pasay");
                break;
            default:
                cityName = "Manila";
                System.out.println("Invalid selection. Defaulting to Manila.");
                break;
        }

        input.nextLine();

        do {
            System.out.print("Enter fan's age: ");
            age = input.nextInt();

            if (age >= 18) {
                System.out.println("You are eligible to attend the tour!");
                fanCount++;
            } else {
                System.out.println("Sorry, you must be 18 or older to attend.");
            }

            input.nextLine();
            System.out.print("Do you want to register another person? (yes/no): ");
            more = input.nextLine();

        } while (more.equalsIgnoreCase("yes"));

        System.out.println("Total fans registered: " + fanCount + " for the " + cityName + " tour!");

        input.close();
    }
}