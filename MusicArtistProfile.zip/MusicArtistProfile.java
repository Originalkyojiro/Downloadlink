import java.util.Scanner;

public class MusicArtistProfile {
    public static void main(String[] args) {
          // This is a single-line comment
          
            Scanner input = new Scanner (System.in); {
            String artistName;
            int debutYear;
            double albumSales;
            String genre;
            boolean isOnTour;
            
            System.out.print("Enter artist name: ");
            artistName = input.nextLine();
            System.out.print("Enter debut year: ");
            debutYear = input.nextInt();
            System.out.print("Enter album sales (in millions): ");
            albumSales = input.nextDouble();
            input.nextLine();
            System.out.print("Enter genre: ");
            genre = input.nextLine();
            System.out.print("Is the artist currently on tour? (true/false): ");
            isOnTour = input.nextBoolean();
            System.out.println("\n--- Artist Profile ---");
            System.out.println("Name: " + artistName);
            System.out.println("Debut Year: " + debutYear);
            System.out.println("Album Sales: " + albumSales + " million");
            System.out.println("Genre: " + genre);
            System.out.println("Currently on Tour: " + isOnTour);
        }
    }
}